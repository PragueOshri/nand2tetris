public enum eTokenType {
    T_KEYWORD,
    T_SYMBOL,
    T_INTEGERCONSTANT,
    T_STRINGCONSTANT,
    T_IDENTIFIER
}
